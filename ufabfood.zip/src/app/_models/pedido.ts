import { ItemPedido } from './item-pedido';

export class Pedido {

    id: number;
    pratos: ItemPedido[];

}