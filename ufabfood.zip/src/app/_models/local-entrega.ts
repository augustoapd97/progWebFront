export class LocalEntrega {
    id: number;
    local: string;
}
