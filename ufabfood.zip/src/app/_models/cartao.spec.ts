import { Cartao } from './cartao';

describe('Cartao', () => {
  it('should create an instance', () => {
    expect(new Cartao()).toBeTruthy();
  });
});
