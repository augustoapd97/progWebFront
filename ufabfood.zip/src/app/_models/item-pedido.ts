import { Prato } from './prato';

export class ItemPedido {
    prato: Prato;
    quantidade: number;
}
