export class Cartao {
    id: number;
    codigo: string;
    validade: Date;
    nome: string
}
