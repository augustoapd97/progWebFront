

export const ITENS = [
    {
        prato: {
            id: 1,
            descricao: 'Lagosta',
            foto: '',
            preco: 100,
            tempo: 20,
            categoria: {id: 1, nome: 'categoria 1'}
        },
        quantidade: 1
    },
    {
        prato: {
            id: 2,
            descricao: 'Hamburguer',
            foto: '',
            preco: 20,
            tempo: 30,
            categoria: {id: 2, nome: 'categoria 2'}
        },
        quantidade: 1
    },
    {
        prato: {
            id: 3,
            descricao: 'Macarrão',
            foto: '',
            preco: 30,
            tempo: 15,
            categoria: {id: 1, nome: 'categoria 1'}
        },
        quantidade: 1
    }
]
